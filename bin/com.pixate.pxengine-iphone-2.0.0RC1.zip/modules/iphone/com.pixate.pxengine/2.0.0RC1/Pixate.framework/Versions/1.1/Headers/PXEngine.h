//
//  PXEngine.h
//  Pixate
//
//  Created by Kevin Lindsey on 9/6/13.
//  Copyright (c) 2013 Pixate, Inc. All rights reserved.
//

#ifndef Pixate_PXEngine_h
#define Pixate_PXEngine_h

#define PXEngine Pixate
#import <Pixate/Pixate.h>

#endif
