//
//  UIView+PXStyling.h
//  PXButtonDemo
//
//  Created by Kevin Lindsey on 8/22/12.
//  Copyright (c) 2012 Pixate, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PXStyleable.h"

@interface UIView (PXStyling) <PXStyleable>

@end

